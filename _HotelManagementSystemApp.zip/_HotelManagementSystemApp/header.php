<meta charset="UTF-8">
        
        <link href="css/w3.css" rel="stylesheet" type="text/css"/>
        <script src="script/user.js" type="text/javascript"></script>
        <script src="script/w3.js" type="text/javascript"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script src="script/modal.js" type="text/javascript"></script>
        <script src="script/account.js" type="text/javascript"></script>
        <style>
            input{
                outline: 0;
            }
        </style>
        