<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Services
 *
 * @author Admin
 */
class Services {
    //put your code here
    public $ServiceID;
    public $ServiceName;
    public $CategoryName;
    public $Description;
    public $Price;
    public $Category_ID;
}
