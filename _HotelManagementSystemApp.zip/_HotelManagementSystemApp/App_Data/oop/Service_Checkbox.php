<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Service_Checkbox
 *
 * @author Admin
 */
class Service_Checkbox {
    //put your code here
    public $ServiceID;
    public $ServiceName;
    public $Check;
}
